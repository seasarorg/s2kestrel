package org.seasar.kestrel.sql;

/**
 * @author Satoshi Kimura
 */
public interface Types {
    int BOOLEAN = 16;

}

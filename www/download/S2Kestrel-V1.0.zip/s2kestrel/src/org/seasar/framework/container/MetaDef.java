package org.seasar.framework.container;

/**
 * @author higa
 *
 */
public interface MetaDef extends ArgDef {

	public String getName();
}
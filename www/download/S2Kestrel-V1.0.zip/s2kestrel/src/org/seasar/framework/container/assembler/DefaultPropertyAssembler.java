package org.seasar.framework.container.assembler;

import org.seasar.framework.container.ComponentDef;

/**
 * @author higa
 *
 */
public class DefaultPropertyAssembler extends AbstractPropertyAssembler {

	/**
	 * @param componentDef
	 */
	public DefaultPropertyAssembler(ComponentDef componentDef) {
		super(componentDef);
	}

	public void assemble(Object component) {
	}

}

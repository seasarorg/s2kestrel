package org.seasar.extension.timer;

public interface TimeoutTarget {

  public void expired();
}
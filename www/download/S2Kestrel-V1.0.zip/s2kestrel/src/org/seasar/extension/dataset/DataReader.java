package org.seasar.extension.dataset;

/**
 * @author higa
 *
 */
public interface DataReader {

	public DataSet read();
}

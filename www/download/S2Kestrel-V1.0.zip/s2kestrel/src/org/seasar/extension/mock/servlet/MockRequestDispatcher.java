package org.seasar.extension.mock.servlet;

import javax.servlet.RequestDispatcher;

/**
 * @author Satoshi Kimura
 */
public interface MockRequestDispatcher extends RequestDispatcher {

}

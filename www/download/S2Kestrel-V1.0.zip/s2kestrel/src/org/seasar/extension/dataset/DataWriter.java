package org.seasar.extension.dataset;

/**
 * @author higa
 *
 */
public interface DataWriter {

	public void write(DataSet dataSet);
}

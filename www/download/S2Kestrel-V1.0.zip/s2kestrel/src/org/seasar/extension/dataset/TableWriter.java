package org.seasar.extension.dataset;

/**
 * @author higa
 *
 */
public interface TableWriter {

	public void write(DataTable table);
}

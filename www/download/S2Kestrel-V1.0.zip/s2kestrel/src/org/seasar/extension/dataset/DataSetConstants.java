package org.seasar.extension.dataset;

/**
 * @author higa
 *
 */
public interface DataSetConstants {

	public String DATE_FORMAT = "yyyy/MM/dd";
	public String BASE64_FORMAT = "\\B\\:@";
	public String TABLE_KEY = "table";
}

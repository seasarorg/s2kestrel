package org.seasar.extension.dataset;

/**
 * @author higa
 *
 */
public interface TableReader {

	public DataTable read();
}
